;;; Generated package description from hl-todo.el  -*- no-byte-compile: t -*-
(define-package "hl-todo" "0.0.0" "Highlight TODO and similar keywords" '((emacs "25.1") (compat "29.1.4.2")) :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :keywords '("convenience") :url "https://github.com/tarsius/hl-todo")
