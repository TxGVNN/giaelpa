;;; Generated package description from hl-todo.el  -*- no-byte-compile: t -*-
(define-package "hl-todo" "0.0.0" "Highlight TODO and similar keywords" '((emacs "26.1") (compat "30.0.0.0")) :authors '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev")) :maintainer '("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev") :keywords '("convenience") :url "https://github.com/tarsius/hl-todo")
