;;; Generated package description from gntp.el  -*- no-byte-compile: t -*-
(define-package "gntp" "0.1" "Growl Notification Protocol for Emacs" 'nil :authors '(("Engelke Eschner" . "tekai@gmx.li")) :maintainer '("Engelke Eschner" . "tekai@gmx.li"))
