;;; Generated package description from crux.el  -*- no-byte-compile: t -*-
(define-package "crux" "0.5.0.20240808" "A Collection of Ridiculously Useful eXtensions" '((emacs "26.1")) :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev")) :maintainer '("Bozhidar Batsov" . "bozhidar@batsov.dev") :keywords '("convenience") :url "https://github.com/bbatsov/crux")
