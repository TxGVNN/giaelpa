;;; Generated package description from ansible-doc.el  -*- no-byte-compile: t -*-
(define-package "ansible-doc" "0.4" "Ansible documentation Minor Mode" '((emacs "24.3")) :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn")) :maintainer '("Sebastian Wiesner" . "swiesner@lunaryorn") :keywords '("tools" "help") :url "https://github.com/lunaryorn/ansible-doc.el")
