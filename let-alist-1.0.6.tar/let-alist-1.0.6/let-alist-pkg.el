;;; Generated package description from let-alist.el  -*- no-byte-compile: t -*-
(define-package "let-alist" "1.0.6" "Easily let-bind values of an assoc-list by their names" '((emacs "24.1")) :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com")) :maintainer '("Artur Malabarba" . "emacs@endlessparentheses.com") :keywords '("extensions" "lisp"))
