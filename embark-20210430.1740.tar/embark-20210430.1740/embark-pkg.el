(define-package "embark" "20210430.1740" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "05aa11bca37db1751c86fe78f784741be5b1a066" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
