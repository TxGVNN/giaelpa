(define-package "consult" "20210508.1118" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "249adbec8b9b5ae205beebcecdeb410529df54d7" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
