(define-package "consult" "20210208.2315" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "bdb414a37e44f01d02f6392af66fa4aee7585b80" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
