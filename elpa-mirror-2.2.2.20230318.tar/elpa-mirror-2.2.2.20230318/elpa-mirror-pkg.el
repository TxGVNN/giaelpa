;;; Generated package description from elpa-mirror.el  -*- no-byte-compile: t -*-
(define-package "elpa-mirror" "2.2.2.20230318" "Create local package repository from installed packages" '((emacs "25.1")) :authors '(("Chen Bin" . "chenbin.sh@gmail.com")) :maintainer '("Chen Bin" . "chenbin.sh@gmail.com") :keywords '("tools") :url "http://github.com/redguardtoo/elpa-mirror")
