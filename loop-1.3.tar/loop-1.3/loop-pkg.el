;;; Generated package description from loop.el  -*- no-byte-compile: t -*-
(define-package "loop" "1.3" "friendly imperative loop structures" 'nil :authors '(("Wilfred Hughes" . "me@wilfred.me.uk")) :maintainer '("Wilfred Hughes" . "me@wilfred.me.uk") :keywords '("loop" "while" "for each" "break" "continue"))
