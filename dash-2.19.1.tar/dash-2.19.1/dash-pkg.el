;;; Generated package description from dash.el  -*- no-byte-compile: t -*-
(define-package "dash" "2.19.1" "A modern list library for Emacs" '((emacs "24")) :authors '(("Magnar Sveen" . "magnars@gmail.com")) :maintainer '("Magnar Sveen" . "magnars@gmail.com") :keywords '("extensions" "lisp") :url "https://github.com/magnars/dash.el")
