;;; Generated package description from envrc.el  -*- no-byte-compile: t -*-
(define-package "envrc" "0.0.0" "Support for `direnv' that operates buffer-locally" '((emacs "26.1") (inheritenv "0.1")) :authors '(("Steve Purcell" . "steve@sanityinc.com")) :maintainer '("Steve Purcell" . "steve@sanityinc.com") :keywords '("processes" "tools") :url "https://github.com/purcell/envrc")
