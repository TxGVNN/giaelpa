;;; Generated package description from 0x0.el  -*- no-byte-compile: t -*-
(define-package "0x0" "1.0.1" "Upload sharing to 0x0.st" '((emacs "26.1")) :authors '(("William Vaughn" . "vaughnwilld@gmail.com")) :maintainer '("William Vaughn" . "vaughnwilld@gmail.com") :url "https://git.sr.ht/~willvaughn/emacs-0x0")
