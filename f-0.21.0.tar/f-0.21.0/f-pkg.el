;;; Generated package description from f.el  -*- no-byte-compile: t -*-
(define-package "f" "0.21.0" "Modern API for working with files and directories" '((emacs "24.1") (s "1.7.0") (dash "2.2.0")) :authors '(("Johan Andersson" . "johan.rejeep@gmail.com")) :maintainer '("Lucien Cartier-Tilet" . "lucien@phundrak.com") :keywords '("files" "directories") :url "http://github.com/rejeep/f.el")
