;;; Generated package description from jq-mode.el  -*- no-byte-compile: t -*-
(define-package "jq-mode" "0.4.1" "Edit jq scripts." '((emacs "25.1")) :authors '(("Bjarte Johansen" . "BjartedotJohansenatgmaildotcom")) :maintainer '("Bjarte Johansen" . "BjartedotJohansenatgmaildotcom") :url "https://github.com/ljos/jq-mode")
