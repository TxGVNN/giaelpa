;;; Generated package description from shut-up.el  -*- no-byte-compile: t -*-
(define-package "shut-up" "0.3.2" "Shut up would you!" '((cl-lib "0.3") (emacs "24")) :authors '(("Johan Andersson" . "johan.rejeep@gmail.com")) :maintainer '("Johan Andersson" . "johan.rejeep@gmail.com") :url "http://github.com/rejeep/shut-up.el")
