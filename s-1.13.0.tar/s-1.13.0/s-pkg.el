;;; Generated package description from s.el  -*- no-byte-compile: t -*-
(define-package "s" "1.13.0" "The long lost Emacs string manipulation library." 'nil :authors '(("Magnar Sveen" . "magnars@gmail.com")) :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :keywords '("strings"))
