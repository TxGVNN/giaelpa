;;; Generated package description from consult.el  -*- no-byte-compile: t -*-
(define-package "consult" "2.7" "Consulting completing-read" '((emacs "28.1") (compat "30")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("matching" "files" "completion") :url "https://github.com/minad/consult")
