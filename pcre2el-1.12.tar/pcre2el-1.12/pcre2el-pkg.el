;;; Generated package description from pcre2el.el  -*- no-byte-compile: t -*-
(define-package "pcre2el" "1.12" "regexp syntax converter" '((emacs "25.1")) :authors '(("joddie" . "jonxfieldatgmail.com")) :maintainer '("joddie" . "jonxfieldatgmail.com") :url "https://github.com/joddie/pcre2el")
