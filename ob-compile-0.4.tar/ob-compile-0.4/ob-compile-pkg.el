;;; Generated package description from ob-compile.el  -*- no-byte-compile: t -*-
(define-package "ob-compile" "0.4" "Run compile by org-babel" '((emacs "24.4")) :authors '(("Giap Tran" . "txgvnn@gmail.com")) :maintainer '("Giap Tran" . "txgvnn@gmail.com") :keywords '("literate programming" "reproducible" "processes" "compilation") :url "https://github.com/TxGVNN/ob-compile")
