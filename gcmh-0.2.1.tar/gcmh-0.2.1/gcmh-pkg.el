;;; Generated package description from gcmh.el  -*- no-byte-compile: t -*-
(define-package "gcmh" "0.2.1" "the Garbage Collector Magic Hack" '((emacs "24")) :authors '(("Andrea Corallo" . "akrl@sdf.org")) :maintainer '(nil . "akrl@sdf.org") :keywords '("internal") :url "https://gitlab.com/koral/gcmh")
