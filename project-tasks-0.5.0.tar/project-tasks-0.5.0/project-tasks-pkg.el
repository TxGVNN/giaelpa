;;; Generated package description from project-tasks.el  -*- no-byte-compile: t -*-
(define-package "project-tasks" "0.5.0" "Efficient task management for your project" '((emacs "26.1") (project "0.6.0")) :authors '(("Giap Tran" . "txgvnn@gmail.com")) :maintainer '("Giap Tran" . "txgvnn@gmail.com") :keywords '("project" "workflow" "tools") :url "https://github.com/TxGVNN/project-tasks")
