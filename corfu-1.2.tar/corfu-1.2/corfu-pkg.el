;;; Generated package description from corfu.el  -*- no-byte-compile: t -*-
(define-package "corfu" "1.2" "COmpletion in Region FUnction" '((emacs "27.1") (compat "29.1.4.4")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("abbrev" "convenience" "matching" "completion" "text") :url "https://github.com/minad/corfu")
