;;; Generated package description from beacon.el  -*- no-byte-compile: t -*-
(define-package "beacon" "1.3.3" "Highlight the cursor whenever the window scrolls" '((seq "2.14")) :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com")) :maintainer '("Artur Malabarba" . "emacs@endlessparentheses.com") :keywords '("convenience") :url "https://github.com/Malabarba/beacon")
