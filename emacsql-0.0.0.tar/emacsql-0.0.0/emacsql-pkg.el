;;; Generated package description from emacsql.el  -*- no-byte-compile: t -*-
(define-package "emacsql" "0.0.0" "High-level SQL database front-end" '((emacs "25.1")) :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev") :url "https://github.com/magit/emacsql")
