;;; Generated package description from emacsql.el  -*- no-byte-compile: t -*-
(define-package "emacsql" "0.0.0" "High-level SQL database front-end" '((emacs "25.1")) :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :url "https://github.com/magit/emacsql")
