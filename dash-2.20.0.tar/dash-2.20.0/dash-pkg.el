;;; Generated package description from dash.el  -*- no-byte-compile: t -*-
(define-package "dash" "2.20.0" "A modern list library for Emacs" '((emacs "24")) :authors '(("Magnar Sveen" . "magnars@gmail.com")) :maintainer '("Basil L. Contovounesios" . "basil@contovou.net") :keywords '("extensions" "lisp") :url "https://github.com/magnars/dash.el")
