;;; Generated package description from cape.el  -*- no-byte-compile: t -*-
(define-package "cape" "2.1" "Completion At Point Extensions" '((emacs "28.1") (compat "30")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("abbrev" "convenience" "matching" "completion" "text") :url "https://github.com/minad/cape")
