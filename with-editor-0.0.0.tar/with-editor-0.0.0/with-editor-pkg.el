;;; Generated package description from with-editor.el  -*- no-byte-compile: t -*-
(define-package "with-editor" "0.0.0" "Use the Emacsclient as $EDITOR" '((emacs "25.1") (compat "29.1.4.1")) :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :keywords '("processes" "terminals") :url "https://github.com/magit/with-editor")
