;;; Generated package description from inheritenv.el  -*- no-byte-compile: t -*-
(define-package "inheritenv" "0.2" "Make temp buffers inherit buffer-local environment variables" '((emacs "24.4")) :authors '(("Steve Purcell" . "steve@sanityinc.com")) :maintainer '("Steve Purcell" . "steve@sanityinc.com") :keywords '("unix") :url "https://github.com/purcell/inheritenv")
