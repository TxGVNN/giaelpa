;;; Generated package description from eat.el  -*- no-byte-compile: t -*-
(define-package "eat" "0.9.4" "Emulate A Terminal, in a region, in a buffer and in Eshell" '((emacs "26.1") (compat "29.1")) :authors '(("Akib Azmain Turja" . "akib@disroot.org")) :maintainer '("Akib Azmain Turja" . "akib@disroot.org") :keywords '("terminals" "processes") :url "https://codeberg.org/akib/emacs-eat")
