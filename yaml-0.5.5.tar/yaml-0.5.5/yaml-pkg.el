;;; Generated package description from yaml.el  -*- no-byte-compile: t -*-
(define-package "yaml" "0.5.5" "YAML parser for Elisp" '((emacs "25.1")) :authors '(("Zachary Romero" . "zkry@posteo.org")) :maintainer '("Zachary Romero" . "zkry@posteo.org") :keywords '("tools") :url "https://github.com/zkry/yaml.el")
