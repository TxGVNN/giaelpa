;;; Generated package description from docker-compose-mode.el  -*- no-byte-compile: t -*-
(define-package "docker-compose-mode" "1.1.0" "Major mode for editing docker-compose files" '((emacs "24.3") (dash "2.12.0") (yaml-mode "0.0.12")) :keywords '("convenience") :url "https://github.com/meqif/docker-compose-mode")
