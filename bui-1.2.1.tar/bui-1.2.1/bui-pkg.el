;;; Generated package description from bui.el  -*- no-byte-compile: t -*-
(define-package "bui" "1.2.1" "Buffer interface library" '((emacs "24.3") (dash "2.11.0")) :authors '(("Alex Kost" . "alezost@gmail.com")) :maintainer '("Alex Kost" . "alezost@gmail.com") :keywords '("tools") :url "https://github.com/alezost/bui.el")
