;;; Generated package description from shrink-path.el  -*- no-byte-compile: t -*-
(define-package "shrink-path" "0.3.1" "fish-style path" '((s "1.6.1") (dash "1.8.0") (f "0.10.0")) :keywords '("path") :url "https://gitlab.com/bennya/shrink-path.el")
