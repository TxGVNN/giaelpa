;;; Generated package description from wgrep.el  -*- no-byte-compile: t -*-
(define-package "wgrep" "3.0.0" "Writable grep buffer" '((emacs "25.1")) :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")) :maintainer '("Masahiro Hayashi" . "mhayashi1120@gmail.com") :keywords '("grep" "edit" "extensions") :url "http://github.com/mhayashi1120/Emacs-wgrep/raw/master/wgrep.el")
