;;; Generated package description from embark.el  -*- no-byte-compile: t -*-
(define-package "embark" "1.1.1" "Conveniently act on minibuffer completions" '((emacs "27.1") (compat "29.1.4.0")) :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")) :maintainer '("Omar Antolín Camarena" . "omar@matem.unam.mx") :keywords '("convenience") :url "https://github.com/oantolin/embark")
