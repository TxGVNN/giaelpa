;;; Generated package description from llama.el  -*- no-byte-compile: t -*-
(define-package "llama" "0.0.0" "Compact syntax for short lambda" '((emacs "26.1") (compat "30.1")) :keywords '("extensions") :url "https://github.com/tarsius/llama")
