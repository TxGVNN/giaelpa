;;; Generated package description from isearch-mb.el  -*- no-byte-compile: t -*-
(define-package "isearch-mb" "0.8" "Control isearch from the minibuffer" '((emacs "27.1")) :authors '(("Augusto Stoffel" . "arstoffel@gmail.com")) :maintainer '("Augusto Stoffel" . "arstoffel@gmail.com") :keywords '("matching") :url "https://github.com/astoff/isearch-mb")
