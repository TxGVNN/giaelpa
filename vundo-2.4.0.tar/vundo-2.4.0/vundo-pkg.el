;;; Generated package description from vundo.el  -*- no-byte-compile: t -*-
(define-package "vundo" "2.4.0" "Visual undo tree" '((emacs "28.1")) :authors '(("Yuan Fu" . "casouri@gmail.com")) :maintainer '("Yuan Fu" . "casouri@gmail.com") :keywords '("undo" "text" "editing") :url "https://github.com/casouri/vundo")
