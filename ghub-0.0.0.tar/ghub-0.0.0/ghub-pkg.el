;;; Generated package description from ghub.el  -*- no-byte-compile: t -*-
(define-package "ghub" "0.0.0" "Client libraries for Git forge APIs" 'nil :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :keywords '("tools") :url "https://github.com/magit/ghub")
