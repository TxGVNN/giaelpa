;;; Generated package description from orderless.el  -*- no-byte-compile: t -*-
(define-package "orderless" "1.0" "Completion style for matching regexps in any order" '((emacs "26.1")) :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")) :maintainer '("Omar Antolín Camarena" . "omar@matem.unam.mx") :keywords '("extensions") :url "https://github.com/oantolin/orderless")
