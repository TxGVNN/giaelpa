;;; Generated package description from simple-httpd.el  -*- no-byte-compile: t -*-
(define-package "simple-httpd" "1.5.1" "pure elisp HTTP server" '((cl-lib "0.3")) :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Christopher Wellons" . "wellons@nullprogram.com") :url "https://github.com/skeeto/emacs-http-server")
