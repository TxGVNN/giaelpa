;;; Generated package description from crux.el  -*- no-byte-compile: t -*-
(define-package "crux" "0.4.0.20231015" "A Collection of Ridiculously Useful eXtensions" '((seq "1.11") (shrink-path "0.3.1")) :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev")) :maintainer '("Bozhidar Batsov" . "bozhidar@batsov.dev") :keywords '("convenience") :url "https://github.com/bbatsov/crux")
