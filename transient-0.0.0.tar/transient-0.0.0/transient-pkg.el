;;; Generated package description from transient.el  -*- no-byte-compile: t -*-
(define-package "transient" "0.0.0" "Transient commands" '((emacs "26.1") (compat "30.1") (seq "2.24")) :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")) :maintainer '("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev") :keywords '("extensions") :url "https://github.com/magit/transient")
