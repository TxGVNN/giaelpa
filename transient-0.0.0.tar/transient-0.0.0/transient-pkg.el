;;; Generated package description from transient.el  -*- no-byte-compile: t -*-
(define-package "transient" "0.0.0" "Transient commands" '((emacs "26.1") (compat "29.1.4.4") (seq "2.24")) :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :keywords '("extensions") :url "https://github.com/magit/transient")
