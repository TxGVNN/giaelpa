;;; Generated package description from marshal.el  -*- no-byte-compile: t -*-
(define-package "marshal" "0.9.1" "eieio extension for automatic (un)marshalling" '((emacs "25.1") (ht "2.0")) :authors '(("Yann Hodique" . "yann.hodique@gmail.com")) :maintainer '("Yann Hodique" . "yann.hodique@gmail.com") :keywords '("extensions") :url "https://github.com/sigma/marshal.el")
