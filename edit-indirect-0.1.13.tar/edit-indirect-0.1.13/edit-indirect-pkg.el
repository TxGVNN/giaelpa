;;; Generated package description from edit-indirect.el  -*- no-byte-compile: t -*-
(define-package "edit-indirect" "0.1.13" "Edit regions in separate buffers" '((emacs "24.3")) :authors '(("Fanael Linithien" . "fanael4@gmail.com")) :maintainer '("Fanael Linithien" . "fanael4@gmail.com") :url "https://github.com/Fanael/edit-indirect")
