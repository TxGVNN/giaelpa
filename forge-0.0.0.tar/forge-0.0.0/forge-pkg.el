;;; Generated package description from forge.el  -*- no-byte-compile: t -*-
(define-package "forge" "0.0.0" "Access Git forges from Magit" 'nil :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :keywords '("git" "tools" "vc") :url "https://github.com/magit/forge")
