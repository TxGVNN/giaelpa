;;; Generated package description from gist.el  -*- no-byte-compile: t -*-
(define-package "gist" "1.5.0.20240204" "Emacs integration for gist.github.com" '((emacs "24.1") (gh "0.10.0")) :authors '(("Yann Hodique" . "yann.hodique@gmail.com")) :maintainer '("Yann Hodique" . "yann.hodique@gmail.com") :keywords '("tools") :url "https://github.com/defunkt/gist.el")
