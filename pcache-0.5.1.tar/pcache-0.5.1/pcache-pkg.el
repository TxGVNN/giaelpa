;;; Generated package description from pcache.el  -*- no-byte-compile: t -*-
(define-package "pcache" "0.5.1" "persistent caching for Emacs." '((emacs "25.1")) :authors '(("Yann Hodique" . "yann.hodique@gmail.com")) :maintainer '("Yann Hodique" . "yann.hodique@gmail.com") :keywords '("extensions"))
