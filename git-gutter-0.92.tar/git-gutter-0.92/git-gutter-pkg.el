;;; Generated package description from git-gutter.el  -*- no-byte-compile: t -*-
(define-package "git-gutter" "0.92" "Port of Sublime Text plugin GitGutter" '((emacs "25.1")) :authors '(("Syohei YOSHIDA" . "syohex@gmail.com")) :maintainer '("Neil Okamoto" . "neil.okamoto+melpa@gmail.com") :url "https://github.com/emacsorphanage/git-gutter")
