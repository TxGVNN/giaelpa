;;; Generated package description from elisp-refs.el  -*- no-byte-compile: t -*-
(define-package "elisp-refs" "1.5" "find callers of elisp functions or macros" '((dash "2.12.0") (s "1.11.0")) :authors '(("Wilfred Hughes" . "me@wilfred.me.uk")) :maintainer '("Wilfred Hughes" . "me@wilfred.me.uk") :keywords '("lisp"))
