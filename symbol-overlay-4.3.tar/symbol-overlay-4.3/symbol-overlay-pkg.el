;;; Generated package description from symbol-overlay.el  -*- no-byte-compile: t -*-
(define-package "symbol-overlay" "4.3" "Highlight symbols with keymap-enabled overlays" '((emacs "24.3") (seq "2.2")) :authors '(("wolray" . "wolray@foxmail.com")) :maintainer '("wolray" . "wolray@foxmail.com") :keywords '("faces" "matching") :url "https://github.com/wolray/symbol-overlay/")
