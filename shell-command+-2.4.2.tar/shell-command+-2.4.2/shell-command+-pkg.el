;;; Generated package description from shell-command+.el  -*- no-byte-compile: t -*-
(define-package "shell-command+" "2.4.2" "An extended shell-command" '((emacs "24.3")) :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht") :keywords '("unix" "processes" "convenience") :url "https://git.sr.ht/~pkal/shell-command-plus")
