;;; Generated package description from x509-mode.el  -*- no-byte-compile: t -*-
(define-package "x509-mode" "0.0.0" "View certificates, CRLs and keys using OpenSSL" '((emacs "25.1")) :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com")) :maintainer '("Fredrik Axelsson" . "f.axelsson@gmail.com") :url "https://github.com/jobbflykt/x509-mode")
