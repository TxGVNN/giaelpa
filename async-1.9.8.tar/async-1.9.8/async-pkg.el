;;; Generated package description from async.el  -*- no-byte-compile: t -*-
(define-package "async" "1.9.8" "Asynchronous processing in Emacs" '((emacs "24.4")) :authors '(("John Wiegley" . "jwiegley@gmail.com")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net") :keywords '("async") :url "https://github.com/jwiegley/emacs-async")
