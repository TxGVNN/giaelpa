;;; Generated package description from multiple-cursors.el  -*- no-byte-compile: t -*-
(define-package "multiple-cursors" "0.0.0" "Multiple cursors for emacs." '((cl-lib "0.5")) :authors '(("Magnar Sveen" . "magnars@gmail.com")) :maintainer '("Magnar Sveen" . "magnars@gmail.com") :keywords '("editing" "cursors") :url "https://github.com/magnars/multiple-cursors.el")
