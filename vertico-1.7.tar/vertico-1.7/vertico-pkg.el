;;; Generated package description from vertico.el  -*- no-byte-compile: t -*-
(define-package "vertico" "1.7" "VERTical Interactive COmpletion" '((emacs "27.1") (compat "29.1.4.4")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("convenience" "files" "matching" "completion") :url "https://github.com/minad/vertico")
