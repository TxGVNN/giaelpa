;;; Generated package description from ht.el  -*- no-byte-compile: t -*-
(define-package "ht" "2.3" "The missing hash table library for Emacs" '((dash "2.12.0")) :authors '(("Wilfred Hughes" . "me@wilfred.me.uk")) :maintainer '("Wilfred Hughes" . "me@wilfred.me.uk") :keywords '("hash table" "hash map" "hash"))
