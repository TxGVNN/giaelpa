;;; Generated package description from yasnippet.el  -*- no-byte-compile: t -*-
(define-package "yasnippet" "0.14.0" "Yet another snippet extension for Emacs" '((cl-lib "0.5")) :maintainer '("Noam Postavsky" . "npostavs@gmail.com") :keywords '("convenience" "emulation") :url "http://github.com/joaotavora/yasnippet")
