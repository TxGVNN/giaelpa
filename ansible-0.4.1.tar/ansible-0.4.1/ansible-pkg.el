;;; Generated package description from ansible.el  -*- no-byte-compile: t -*-
(define-package "ansible" "0.4.1" "Ansible minor mode" '((s "1.9.0") (f "0.16.2") (emacs "25.1")) :authors '((nil . "k1lowxb[at]gmail[dot]com") (nil . "k1low[at]101000lab[dot]org")) :maintainer '(nil . "k1lowxb[at]gmail[dot]com") :url "https://gitlab.com/emacs-ansible/emacs-ansible")
