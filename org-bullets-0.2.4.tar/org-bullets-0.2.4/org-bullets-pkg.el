;;; Generated package description from org-bullets.el  -*- no-byte-compile: t -*-
(define-package "org-bullets" "0.2.4" "Show bullets in org-mode as UTF-8 characters" 'nil :url "https://github.com/sabof/org-bullets")
