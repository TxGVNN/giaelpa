;;; Generated package description from engine-mode.el  -*- no-byte-compile: t -*-
(define-package "engine-mode" "2.2.4" "Define and query search engines" '((cl-lib "0.5")) :authors '(("Harry R. Schwartz" . "hello@harryrschwartz.com")) :maintainer '("Harry R. Schwartz" . "hello@harryrschwartz.com") :url "https://github.com/hrs/engine-mode")
