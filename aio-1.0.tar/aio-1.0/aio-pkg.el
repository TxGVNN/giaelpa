;;; Generated package description from aio.el  -*- no-byte-compile: t -*-
(define-package "aio" "1.0" "async/await for Emacs Lisp" '((emacs "26.1")) :authors '(("Christopher Wellons" . "wellons@nullprogram.com")) :maintainer '("Christopher Wellons" . "wellons@nullprogram.com") :url "https://github.com/skeeto/emacs-aio")
