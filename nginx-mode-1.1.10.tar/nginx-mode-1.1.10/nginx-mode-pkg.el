;;; Generated package description from nginx-mode.el  -*- no-byte-compile: t -*-
(define-package "nginx-mode" "1.1.10" "major mode for editing nginx config files" 'nil :authors '(("Andrew J Cosgriff" . "andrew@cosgriff.name")) :maintainer '("Andrew J Cosgriff" . "andrew@cosgriff.name") :keywords '("languages" "nginx"))
