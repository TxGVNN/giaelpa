;;; Generated package description from geiser.el  -*- no-byte-compile: t -*-
(define-package "geiser" "0.32" "GNU Emacs and Scheme talk to each other" '((emacs "27.1") (project "0.8.1")) :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")) :maintainer '("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)") :keywords '("languages" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/")
