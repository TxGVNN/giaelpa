;;; Generated package description from magit-popup.el  -*- no-byte-compile: t -*-
(define-package "magit-popup" "0.0.0" "Define prefix-infix-suffix command combos" '((emacs "24.4") (dash "2.13.0")) :authors '(("Jonas Bernoulli" . "jonas@bernoul.li")) :maintainer '("Jonas Bernoulli" . "jonas@bernoul.li") :keywords '("bindings") :url "https://github.com/magit/magit-popup")
