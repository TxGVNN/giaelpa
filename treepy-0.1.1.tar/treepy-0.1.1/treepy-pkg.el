;;; Generated package description from treepy.el  -*- no-byte-compile: t -*-
(define-package "treepy" "0.1.1" "Generic tree traversal tools" '((emacs "25.1")) :authors '(("Daniel Barreto" . "daniel.barreto.n@gmail.com")) :maintainer '("Daniel Barreto" . "daniel.barreto.n@gmail.com") :keywords '("lisp" "maint" "tools") :url "https://github.com/volrath/treepy.el")
