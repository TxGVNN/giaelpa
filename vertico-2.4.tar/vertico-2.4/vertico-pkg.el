;;; Generated package description from vertico.el  -*- no-byte-compile: t -*-
(define-package "vertico" "2.4" "VERTical Interactive COmpletion" '((emacs "28.1") (compat "30")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("convenience" "files" "matching" "completion") :url "https://github.com/minad/vertico")
