;;; Generated package description from tablist.el  -*- no-byte-compile: t -*-
(define-package "tablist" "1.0" "Extended tabulated-list-mode" '((emacs "24.3")) :authors '(("Andreas Politz" . "politza@fh-trier.de")) :maintainer '("Andreas Politz" . "politza@fh-trier.de") :keywords '("extensions" "lisp"))
