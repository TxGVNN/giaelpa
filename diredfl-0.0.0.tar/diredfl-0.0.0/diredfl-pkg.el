;;; Generated package description from diredfl.el  -*- no-byte-compile: t -*-
(define-package "diredfl" "0.0.0" "Extra font lock rules for a more colourful dired" '((emacs "24")) :authors '(("Steve Purcell" . "steve@sanityinc.com")) :maintainer '("Steve Purcell" . "steve@sanityinc.com") :keywords '("faces") :url "https://github.com/purcell/diredfl")
