;;; Generated package description from logito.el  -*- no-byte-compile: t -*-
(define-package "logito" "0.1" "logging library for Emacs" '((emacs "25.1")) :authors '(("Yann Hodique" . "yann.hodique@gmail.com")) :maintainer '("Yann Hodique" . "yann.hodique@gmail.com") :keywords '("lisp" "extensions"))
