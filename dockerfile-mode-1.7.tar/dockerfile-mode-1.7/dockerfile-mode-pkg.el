;;; Generated package description from dockerfile-mode.el  -*- no-byte-compile: t -*-
(define-package "dockerfile-mode" "1.7" "Major mode for editing Docker's Dockerfiles" '((emacs "24")) :keywords '("docker") :url "https://github.com/spotify/dockerfile-mode")
