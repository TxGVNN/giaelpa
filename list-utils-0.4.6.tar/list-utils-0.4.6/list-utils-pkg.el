;;; Generated package description from list-utils.el  -*- no-byte-compile: t -*-
(define-package "list-utils" "0.4.6" "List-manipulation utility functions" 'nil :authors '(("Roland Walker" . "walker@pobox.com")) :maintainer '("Roland Walker" . "walker@pobox.com") :keywords '("extensions") :url "http://github.com/rolandwalker/list-utils")
