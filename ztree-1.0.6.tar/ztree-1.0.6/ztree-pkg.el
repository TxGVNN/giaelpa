;;; Generated package description from ztree.el  -*- no-byte-compile: t -*-
(define-package "ztree" "1.0.6" "Text mode directory tree" '((cl-lib "0")) :authors '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")) :maintainer '("Alexey Veretennikov" . "alexey.veretennikov@gmail.com") :keywords '("files" "tools") :url "https://github.com/fourier/ztree")
