;;; Generated package description from consult.el  -*- no-byte-compile: t -*-
(define-package "consult" "1.2" "Consulting completing-read" '((emacs "27.1") (compat "29.1.4.4")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("matching" "files" "completion") :url "https://github.com/minad/consult")
